interface ZooAnimals {
  species: string;
  hungry: boolean;
  amount: number;
  weight: number;
}
export default ZooAnimals;
