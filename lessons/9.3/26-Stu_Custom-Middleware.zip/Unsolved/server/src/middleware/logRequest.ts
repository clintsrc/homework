const logRequest = (req: any, _res: any, next: any) => {
  //TODO: log both the incoming request method and url.
  //TODO: call the next function.
};

export default logRequest;
