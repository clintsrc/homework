import './style.css';
const badRequestUrl = 'https://api.github.com/unicorns';
const redirectUrl = './404.html';

const getRequest = async () => {
  // Use a conditional to check the response status.
  // If that status equals the conditional, then redirect to the 404 page.
};
