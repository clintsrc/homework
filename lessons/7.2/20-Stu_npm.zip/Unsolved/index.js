import inquirer from 'inquirer';

inquirer.prompt([
  {
    message: 'Press ENTER to continue...',
    name: 'enterKey',
  },
]);
