// TODO: create a cat object called 'cat' with the following properties: name: string, age: number, pattern: string, isSleepy (optional) : boolean, and siblings (optional) : string[]
// TODO: console.log the cat object
// TODO: console.log the cat's siblings if they exist
