// TODO Create an array containing names of five students in the class with the correct type

// TODO Log length of the students array

// TODO Loop over the array and welcome each student to the class
